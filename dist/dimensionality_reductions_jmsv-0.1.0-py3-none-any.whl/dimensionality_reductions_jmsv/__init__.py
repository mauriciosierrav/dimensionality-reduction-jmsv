__all__ = [
    "decomposition"
    , "manifold"
]
