import numpy as np

class TSNE:
    pass